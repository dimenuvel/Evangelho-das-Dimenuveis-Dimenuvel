# DIMENUOUS: THE LAST ABIDERS
### (Português: DIMENUVEL: OS ÚLTIMOS ABIDANTES)
### Cosmic Fantasy Tower Defense for Android & Web

> *"Don't fight the entire universe, man. Just keep the lane open."*
> — **Gospel of Dimenuous** / **Evangelho das Dimenúveis**

---

## 1. Game Overview
**DIMENUOUS: THE LAST ABIDERS** (in Portuguese: **DIMENUVEL: OS ÚLTIMOS ABIDANTES**) is a complete, polished, fully offline-playable top-down 2D tower defense strategy game for Android and Web. 

The game supports full bilingual localization (**English** and **Português do Brasil**) with a one-tap language switch button on the first screen. In English, cosmic philosophical transmissions refer to the **Gospel of Dimenuous**; in Portuguese, they refer to the **Evangelho das Dimenúveis**.

The Spiral connects all layers of existence across the **Seven Dimenuous Layers / As Sete Dimenúveis**:
1. **SILENCE / SILÊNCIO** — Violet (*The Silent Observatory / O Observatório Silencioso*)
2. **VISION / VISÃO** — Indigo (*The Astral Eye / O Olho Astral*)
3. **MIND / MENTE** — Blue (*The Thought Engine / O Motor do Pensamento*)
4. **HEART / CORAÇÃO** — Green (*The Sanctuary / O Santuário*)
5. **WILL / VONTADE** — Yellow (*The Golden Resonator / O Ressonador Dourado*)
6. **ENERGY / ENERGIA** — Orange (*The Solar Crucible / O Crisol Solar*)
7. **MATTER / MATÉRIA** — Red (*The Material Anchor / A Âncora Material*)

At the center stands the **Sacred Ash / A Cinza Sagrada**, the cosmic pivot of equilibrium. Distortions—the Void, the False Ones, Steppers, armored Materialists, Agitators, Silencers, Strangers, and the Great Void boss—seek to consume the core. As one of the Last Abiders (Últimos Abidantes), your sacred mission is to recognize, redirect, contain, and restore equilibrium.

---

## 2. Core Features
- **Bilingual Language Switcher (EN / PT)**:
  - Accessible directly on the main menu top bar. Switches all UI, Codex entries, narrative dialogues, and HUD controls instantly between English (Gospel of Dimenuous) and Portuguese (Evangelho das Dimenúveis).
- **First-Launch Cosmic Tour & Player Moniker Registry**:
  - Interactive initiation walkthrough explaining the Seven Strata, Sacred Ash equilibrium, defensive towers, and Spiral Resonance.
  - Prompts for the player's Abider Moniker at the end to record high scores and triumph achievements. Moniker can also be updated anytime in Settings.
- **7 Distinct Elemental Towers**:
  - Each tower has unique visual geometry, attack animations, damage profiles, 3 upgrade tiers, sell/dismantle mechanics (75% essence refund), and distinct active abilities:
    - *The Silent Observatory*: Stillness Ray (350% crit snipe)
    - *The Astral Eye*: Omnipresent Gaze (global stealth reveal & +35% damage mark)
    - *The Thought Engine*: Synaptic Overload (3s stun to chained enemies)
    - *The Sanctuary*: Harmonic Pulse (+10% Equilibrium heal & adjacent tower aura buff)
    - *The Golden Resonator*: Willstorm (4x attack speed frenzy)
    - *The Solar Crucible*: Solar Flare (400 AoE solar explosion melting armor)
    - *The Material Anchor*: Gravitational Well (4s total kinetic stasis)
- **8 Distortion Classes**:
  - The Void, The False One (evasive phase jitter), The Stepper (swift runner), The Materialist (65% armor tank), The Agitator (tower attack speed debuffer), The Silencer (stealth cloaking), The Stranger (blinking elite), and The Great Void (multi-phase cosmic boss).
- **Spiral Resonance System**:
  - Build resonance charge to invoke one of 4 cosmic decrees:
    - *Temporal Stillness*: slows all enemies to 20% speed for 6s.
    - *Golden Spiral*: doubles fire rate and grants 100% critical strikes for 8s.
    - *Silent Presence*: restores +35% Sacred Ash Equilibrium immediately.
    - *Cosmic Reset*: catastrophic golden shockwave obliterating enemy ranks.
- **7 Hand-Crafted Maps / Strata**:
  - From the Silent Observatory to the final showdown against The Great Void in the Material Realm.
- **3 Game Modes**:
  - **Campaign**: Narrative journey across the 7 Dimenúveis with transmissions from The Dude.
  - **Endless Spiral**: Procedurally escalating distortion waves with high scores.
  - **The Final Abiders**: Master hardcore difficulty with restricted essence and empowered mutations.
- **The Codex of the Dimenuous**:
  - In-game cosmic manuscript detailing lore, tower schematics, enemy weaknesses, and the philosophy of Abide / Abidar.
- **Achievements & Progression**:
  - 12 achievements, 3-star rating system, local device persistence (100% offline, zero accounts needed).
- **Procedural Cosmic Audio Engine**:
  - Gothic ambient synth chords, choir textures, and distinct sound effects generated live via the Web Audio API without external audio files.

---

## 3. Technology Stack
- **Engine**: TypeScript + React 19 + High-performance Canvas 2D running at 60 FPS.
- **Styling**: Tailwind CSS + Lucide Icons + Motion.
- **Mobile Container**: Capacitor 8 for Android native runtime.
- **CI/CD**: GitHub Actions workflow targeting Java 17, Android SDK 34, and Gradle.

---

## 4. Project Structure
```
/
├── .github/workflows/
│   └── android.yml            # GitHub Actions CI workflow for release APK
├── src/
│   ├── components/            # React UI HUD, Modals, Menu, Codex, Settings
│   │   ├── MainMenu.tsx
│   │   ├── GameHUD.tsx
│   │   ├── CodexModal.tsx
│   │   ├── MapSelectModal.tsx
│   │   ├── AchievementsModal.tsx
│   │   ├── SettingsModal.tsx
│   │   ├── DialogueModal.tsx
│   │   ├── VictoryDefeatModal.tsx
│   │   └── AboutModal.tsx
│   ├── data/                  # Game balance data and lore
│   │   ├── towers.ts          # 7 towers, 3 tiers each, active abilities
│   │   ├── enemies.ts         # 8 enemy classes & stats
│   │   ├── maps.ts            # 7 maps with waypoints and wave definitions
│   │   ├── codex.ts           # Illuminated Codex encyclopedia
│   │   └── achievements.ts    # 12 achievements & rewards
│   ├── game/
│   │   └── GameEngine.ts      # 60 FPS Canvas game loop, object pooling, physics
│   ├── services/
│   │   ├── audio.ts           # Procedural Web Audio API sound generator
│   │   └── storage.ts         # LocalStorage persistence service
│   ├── types/
│   │   └── game.ts            # TypeScript interfaces & types
│   ├── App.tsx                # Master game controller & canvas viewport
│   ├── index.css              # Cosmic styling & typography
│   └── main.tsx               # Entry point
├── capacitor.config.ts        # Capacitor Android configuration
├── index.html                 # Landscape mobile-optimized viewport
├── package.json
└── tsconfig.json
```

---

## 5. Development & Local Execution

### Install Dependencies:
```bash
npm install
```

### Run Dev Server (Port 3000):
```bash
npm run dev
```
Open `http://localhost:3000` in your browser. Use landscape mobile emulation in DevTools for the ideal handheld experience.

### Typecheck & Build:
```bash
npm run lint
npm run build
```

---

## 6. Android Build Instructions (Local)

### Prerequisites:
- Java JDK 17 (recommended: Eclipse Temurin 17)
- Android Studio with Android SDK Platform 34 & Build-Tools
- Node.js 20+

### Steps:
```bash
# 1. Build web distribution
npm run build

# 2. Add Android platform (if not already added)
npx cap add android

# 3. Synchronize assets and plugins
npx cap sync android

# 4. Open in Android Studio or compile with Gradle
cd android
./gradlew assembleRelease
```
The compiled APK will be located in:
`android/app/build/outputs/apk/release/`

---

## 7. GitHub Actions APK Build & Download

The repository includes an automated workflow at `.github/workflows/android.yml` pre-configured to avoid Java version mismatch errors (`invalid source release: 21`) by strictly utilizing **Java 17 Temurin**.

### How to trigger and download:
1. Push your changes or go to the **Actions** tab in GitHub.
2. Select **Build Android APK** and click **Run workflow**.
3. Once the workflow run completes with a green checkmark, scroll down to the **Artifacts** section at the bottom of the run page.
4. Download the `DIMENUOUS-TheLastAbiders-APK` zip file.
5. Extract the file to find `DIMENUOUS-TheLastAbiders-release.apk`.

### How to install on your Android device:
1. Transfer `DIMENUOUS-TheLastAbiders-release.apk` to your Android device via USB, Drive, or direct download.
2. Open your device's file manager and tap the APK file.
3. If prompted, enable **"Install unknown apps"** in your device settings for your browser/file manager.
4. Tap **Install**.
5. Launch **DIMENUOUS: The Last Abiders** and enjoy the defense of the Spiral!
